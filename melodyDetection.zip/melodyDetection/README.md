# Melody-Detection
# Queries
Doc link: https://docs.google.com/document/d/1v4_umrPgAghKfpXk-acIGb30Rq-4n5DT1zqhCjdSrm8/edit
